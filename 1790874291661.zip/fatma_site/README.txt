FATMA & YASIN - BIZIM HIKAYEMIZ

3 soru hazırlandı:
1) İlk nerede birbirimizi gördük? -> Okul
2) İlk defa ne zaman konuşmaya başladık? -> 22.02.2025
3) Beni affettin mi? -> Evet / Hayır

3. soruda Hayır seçilirse Evet butonu eğlenceli şekilde büyür, ancak Hayır seçeneği tamamen kaldırılmaz.
